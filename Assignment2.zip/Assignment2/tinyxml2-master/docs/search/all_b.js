var searchData=
[
  ['openelement',['OpenElement',['../classtinyxml2_1_1_x_m_l_printer.html#a20fb06c83bd13e5140d7dd13af06c010',1,'tinyxml2::XMLPrinter']]],
  ['operator_3d',['operator=',['../classtinyxml2_1_1_x_m_l_handle.html#a75b908322bb4b83be3281b6845252b20',1,'tinyxml2::XMLHandle']]]
];

#pragma once

namespace CppUnitLite
{
	int runAllTests();
}

#pragma once

int main()
{
	int myInt = "hello";
	return 0;
}
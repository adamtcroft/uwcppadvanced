#include "Header.h"
#include "ContainerIterator.h"
#include <iostream>
#include <vector>
#include <algorithm>
#include <chrono>
#include <type_traits>
#include <iterator>
#include <sstream>
#include <numeric>
#include <string_view>
#include <exception>

using namespace std;

class Wrapper
{
public:
	Wrapper(const std::string& in) : data{ in } {}
	Wrapper() = delete;
	Wrapper(const Wrapper&) = default;
	Wrapper(Wrapper&&) = default;
	Wrapper& operator=(const Wrapper&) = default;
	Wrapper& operator=(Wrapper&&) = default;
	~Wrapper() = default;

	const std::string& getData1() const
	{
		return data;
	}

	std::string getData2() const
	{
		return data;
	}

	std::string_view getData3() const
	{
		return data;
	}


private:
	std::string data;
};

int main()
{

	//std::string str{ "" };
	//{
	//	Wrapper w{ "Hello World" };
	//	str = w.getData2();
	//	cout << "Addr of member: " << &w.getData1() << " Addr of str: " << &str << endl;
	//	cout << " Inside scope: " << str.c_str() << std::endl;
	//}

	//cout << "Outside scope: " << str.c_str() << std::endl << endl;

	//Wrapper* w = new Wrapper("Hello World");
	////must be const, or won't compile.
	//const std::string& strRef{ w->getData1() };
	//cout << "Addr of member: " << &w->getData1() << " Addr of strRef: " << &strRef << endl;
	//cout << "Member: " << w->getData1().c_str() << " strRef: " << strRef.c_str() << endl;

	//std::string strFromRefOfPtr{ w->getData1() };
	//cout << "Addr of member: " << &w->getData1() << " Addr of strFromRefOfPtr: " << &strFromRefOfPtr << endl;
	//cout << "Member: " << w->getData1().c_str() << " strRef: " << strFromRefOfPtr.c_str() << endl;

	//string_view view{ w->getData3() };
	//auto memberPayload{ reinterpret_cast<const void*>(w->getData1().data()) };
	//auto viewPayload{ reinterpret_cast<const void*>(view.data()) };
	//cout << "Addr of member's payload: " << memberPayload << " Addr of string_view internal pointer: " << viewPayload << endl;
	//cout << "Member: " << w->getData1().c_str() << " string view: " << view << endl;

	//delete w;
	//try
	//{
	//	cout << "After delete strRef: " << strRef.c_str() << endl;
	//	cout << "After delete strFromRefOfPtr: " << strFromRefOfPtr.c_str() << endl;
	//	cout << "After delete string_view: " << view << endl;
	//}
	//catch (exception& ex)
	//{
	//	cout << "Caught Exception: " << ex.what() << endl;
	//}

	CRTP::DoubleWord crtpDW;
	crtpDW.someFauxVirtualFunction();

	//1234 
	unsigned char c{ 0xb2 };
	std::uint16_t s{ 0xb1b2 };
	std::uint32_t i{ 0xb4b3b2b1 };

	DataTypes::Byte b{ c };

	stringstream s1;
	DataTypes::Byte{ 'A' }.write(s1);

	DataTypes::Word word{ s };
	DataTypes::DoubleWord dw{ i };

	unsigned short aShort = static_cast<unsigned short>(word);
	unsigned short anotherShort = (unsigned short)word;  // works, because we have the operator, but this is an anti-pattern in modern C++.
	
	std::stringstream stream;

	dw.writeLittleEndian(stream);

	std::cout << std::hex << stream.str().c_str() << std::endl;

	DataTypes::DoubleWord dw2 = DataTypes::DoubleWord::readLittleEndian(stream);

	dsa::doubly_linked_list<int> dll;
	dll.push_back(1);
	dll.push_back(2);
	dll.push_back(3);

	std::copy(dll.begin(), dll.end(), std::ostream_iterator<int>(std::cout));

	std::copy(dll.rbegin(), dll.rend(), std::ostream_iterator<int>(std::cout));

	std::vector<int> myVec{ 5 };

	std::iota(myVec.begin(), myVec.end(), 3);

	std::generate_n(std::back_inserter(myVec), 5, []() {return 1; });

	std::sort(myVec.begin(), myVec.end());

	std::sort(myVec.begin(), myVec.end(), std::greater());

	DataTypes::SizedWord_t<long, long> swLL;

	swLL.writeLittleEndian(cout);

	return 0;
}


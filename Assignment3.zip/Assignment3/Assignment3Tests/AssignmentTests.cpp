#pragma once
#include "CppUnitLite.h"

int main()
{
	int results = CppUnitLite::runAllTests();
}

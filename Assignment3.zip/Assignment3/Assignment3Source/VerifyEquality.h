#pragma once
#include "Byte.h"
#include "Word.h"
#include "DoubleWord.h"
#include <string>

class VerifyEquality
{
public:
	VerifyEquality() = delete;
	~VerifyEquality() = delete;

	static void verifyEquality(const Binary::Byte& expected, const Binary::Byte& actual, const std::string& error);
	static void verifyEquality(const Binary::Word& expected, const Binary::Word& actual, const std::string& error);
	static void verifyEquality(const Binary::DoubleWord& expected, const Binary::DoubleWord& actual, const std::string& error);
};

